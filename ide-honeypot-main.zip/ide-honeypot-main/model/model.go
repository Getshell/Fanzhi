package model

type Info struct {
	Host    string
	Command string
	Zipname string
	Port    string
}
