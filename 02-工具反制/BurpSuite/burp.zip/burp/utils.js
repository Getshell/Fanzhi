AbortSignal.timeout = ms => {
  const controller = new AbortController();
  setTimeout(() => controller.abort(), ms);
  return controller.signal;
};

function tryRange(ports, timeout){
      signal = AbortSignal.timeout(timeout)
      return Promise.any(ports.map((port)=>{
        return fetch(`http://127.0.0.1:${port}/devtools/Images/treeoutlineTriangles.svg`,{ mode: 'no-cors', signal }).then(()=>{return port})
      })).catch(()=>{return false});
}

function makeGroups(start, end, size){
  let counter = 0; let ports = [];
  let port_groups = [];
  for(port=start; port > end; port--){
    counter++;
    ports.push(port);
    if(counter % size == 0){
        port_groups.push(ports)
        ports = [];
    }
  }
  port_groups.push(ports);
  return port_groups;
}

async function getPort(start, end, size, timeout, logFn){
    var port_groups = makeGroups(start, end, size);
    for(i=0;i<port_groups.length;i++){
        res = await tryRange(port_groups[i], timeout);
        let group = port_groups[i];
        logFn(`trying ports: ${group[0]} - ${group[group.length-1]}`)
        if(res){return res;}
    }
}
function pageToSocketURL(url) {
  return new Promise(function(resolve, reject) {
      var socket = new WebSocket(url);
      let u = new URL(url);
      async function send(obj){
          return socket.send(JSON.stringify(obj));
      }
      socket.onopen = async function(event) {
          await send({"id": 1, "method": "Page.enable","params": {}});
          await send({"id":2,"method":"Page.navigate","params":{"url":`http:/${u.host}/json/version`}});
      }
      socket.onerror = (err) => {reject(err)};
      socket.onmessage = async (event) => {
          console.log(event)
          let data = {};
          try{
            data = JSON.parse(event.data);
          }catch(e){

          }

          if(data.method && data.method == "Page.loadEventFired"){
              await socket.send(JSON.stringify({
                  "id": 3, "method": "Runtime.evaluate","params": {"expression": "document.body.outerText"}
              }));
          }
          if(data.id ==3){
              socket.close();
              resolve(JSON.parse(data.result.result.value).webSocketDebuggerUrl)
          }
      };        
  });
}